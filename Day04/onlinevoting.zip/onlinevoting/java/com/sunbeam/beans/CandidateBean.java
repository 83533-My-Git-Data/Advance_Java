package com.sunbeam.beans;

public class CandidateBean {

}
